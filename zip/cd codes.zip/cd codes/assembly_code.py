def generate_code(input_data): 
    output='' 
    for line in input_data.splitlines(): 
        values=line.split() 
        if len(values)!=4: 
            print(f'Ignore line:{line.strip()}-not enough values to generate code.') 
            continue 
        op,arg1,arg2,result=values 
        if op=='+': 
            output+=f'\nMOV R0,{arg1}' 
            output+=f'\nADD R0,{arg2}' 
            output+=f'\nMOV {result},R0' 
        elif op=='*': 
            output+=f'\nMOV R0,{arg1}' 
            output+=f'\nMUL R0,{arg2}' 
            output+=f'\nMOV {result},R0'
        elif op=='-': 
            output+=f'\nMOV R0,{arg1}' 
            output+=f'\nSUB R0,{arg2}' 
            output+=f'\nMOV {result},R0'
        elif op=='/': 
            output+=f'\nMOV R0,{arg1}' 
            output+=f'\nDIV R0,{arg2}' 
            output+=f'\nMOV {result},R0'  
        elif op=='=': 
            output+=f'\nMOV R0,{arg1}' 
            output+=f'\nMOV {result},R0' 
    return output 
def main(): 
    input_data='''
    + a b t1 
    * c d t2
    - t1 t2 t 
    = t ? x
    '''
    generated_code=generate_code(input_data) 
    print('Generated Code:') 
    print(generated_code) 
if __name__=='__main__': 
    main()
            