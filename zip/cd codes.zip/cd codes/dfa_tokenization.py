class LexicalAnalyzer:
    def __init__(self):
        self.keywords = {'if', 'else', 'for',
                         'while', 'float', 'int', 'char', 'return'}
        self.symbols = {'+', '-', '*', '/', '<', '>', '=',
                        '{', '}', '(', ')', '@', '$', '!', '&', '%'}
        self.digits = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9'}
        self.letters = set(chr(i) for i in range(65, 91)) | set(
            chr(i) for i in range(97, 123))
        self.whitespace = {' ', '\t', '\n'}
        self.current_token = ''
        self.tokens = []

    def analyze(self, input_string):
        state = 0
        for char in input_string:
            if state == 0:
                if char in self.whitespace:
                    pass
                elif char in self.digits:
                    self.current_token += char
                    state = 1
                elif char in self.letters:
                    self.current_token += char
                    state = 2
                elif char in self.symbols:
                    self.tokens.append((char, 'symbol'))
                else:
                    print("Error: Invalid Character")
            elif state == 1:
                if char in self.digits:
                    self.current_token += char
                else:
                    self.tokens.append((self.current_token, 'number'))
            elif state == 2:
                if char in self.letters or char in self.digits:
                    self.current_token += char
                else:
                    if self.current_token in self.keywords:
                        self.tokens.append((self.current_token, 'keyword'))
                    else:
                        self.tokens.append((self.current_token, 'identifier'))
                    self.current_token = ''
                    state = 0
                    if char not in self.whitespace:
                        self.analyze(char)
        if self.current_token != '':
            if state == 1:
                self.tokens.append((self.current_token, 'number'))
            elif state == 2:
                if self.current_token in self.keywords:
                    self.tokens.append((self.current_token, 'keyword'))
                else:
                    self.tokens.append((self.current_token, 'identifier'))
        return self.tokens


if __name__ == '__main__':
    analyzer = LexicalAnalyzer()
    input_string = input("Enter the string: ")
    tokens = analyzer.analyze(input_string)
    for i in tokens:
        for x in i[0]:
            print(x, '-->', end='')
        print('end:', i[1])
        print('')
    print('final state')
