def find_first(grammar):
    first = {}

    def find_first_set(symbol):
        if symbol in first:
            return first[symbol]
        
        first_set = set()
        
        if symbol not in grammar:
            first_set.add(symbol)
        else:
            for production in grammar[symbol]:
                if not production:
                    first_set.add('epsilon')
                else:
                    for prod_symbol in production:
                        if prod_symbol == symbol:
                            break

                        first_of_symbol = find_first_set(prod_symbol)
                        first_set.update(first_of_symbol - {'epsilon'})
                        
                        if 'epsilon' not in first_of_symbol:
                            break
                    else:
                        first_set.add('epsilon')
        
        first[symbol] = first_set
        return first_set

    for symbol in grammar:
        find_first_set(symbol)
    
    return first

def compute_follow(grammar):
    follow = {non_terminal: set() for non_terminal in grammar}
    start_symbol = list(grammar.keys())[0]
    follow[start_symbol].add('$')

    first = find_first(grammar)
    
    while True:
        updated = False
        for non_terminal, productions in grammar.items():
            for production in productions:
                follow_temp = follow[non_terminal].copy()
                for i in reversed(range(len(production))):
                    symbol = production[i]
                    if symbol in grammar:
                        prev_follow = follow[symbol].copy()
                        follow[symbol].update(follow_temp)
                        if prev_follow != follow[symbol]:
                            updated = True
                        if 'epsilon' in first[symbol]:
                            follow_temp.update(first[symbol] - {'epsilon'})
                        else:
                            follow_temp = first[symbol].copy()
                    else:
                        follow_temp = {symbol}
        
        if not updated:
            break
    
    return follow

def main():
    grammar = {}
    print("Enter the grammar (use '->' as separator, epsilon as 'epsilon', e.g., S -> a S | b):")
    while True:
        production = input().strip()
        if not production:
            break
        left_prod, right_prod = production.split('->')
        left_prod = left_prod.strip()
        right_prod = [prod.strip().split() for prod in right_prod.split("|")]
        grammar[left_prod] = right_prod

    follow_result = compute_follow(grammar)
    print("\nFollow Sets:")
    for non_terminal, follow_set in follow_result.items():
        print(f'Follow({non_terminal}): {follow_set}')

if __name__ == '__main__':
    main()
