import re 
def lexer(program):
    keywords={'if','else','while','for','int','float','char','return','printf','main'}
    operators={'+','-','*','/','==','=','!=','<','>','<=','>=','++','--'}
    statements=program.split('\n')
    statement_number=1 
    
    for statement in statements:
        statement=statement.strip()
        if not statement:
            continue 
        lexemes=re.findall(r'([a-zA-Z][a-zA-Z0-9_]*|".*?"|\d+|\S)',statement)
        for lexeme in lexemes: 
            token='identifier' if lexeme.isidentifier() and lexeme not in keywords else \
            'keyword' if lexeme in keywords else \
                'operator' if lexeme in operators else \
                    'string' if lexeme.startswith('"') and lexeme.endswith('"') else \
                        'constant' if lexeme.isdigit() else \
                            'special character' 
            print(f'{statement_number}\t\t{lexeme}\t\t{token}')
        statement_number+=1 
program='''
int main(){ 
    int x =5;
    int c = x ** 5;
    return 0;
}
'''
lexer(program)
                